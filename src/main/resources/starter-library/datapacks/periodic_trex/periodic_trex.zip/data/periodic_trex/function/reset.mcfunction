data modify storage periodic_trex:global args set value {}
data modify storage periodic_trex stack set value []
gamerule max_command_sequence_length 1000000000
scoreboard objectives add mfam_clock dummy
scoreboard players set #tick mfam_clock 0