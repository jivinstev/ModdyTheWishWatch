scoreboard players add #tick mfam_clock 1
execute if score #tick mfam_clock matches 200.. as @e[tag=wishmob_trex] at @s run effect give @s minecraft:jump_boost infinite 5 true
execute if score #tick mfam_clock matches 200.. run scoreboard players set #tick mfam_clock 0