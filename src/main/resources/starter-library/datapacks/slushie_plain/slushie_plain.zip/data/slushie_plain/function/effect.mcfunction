execute as @s run effect give @s minecraft:saturation 1 4
execute as @s run effect give @s minecraft:speed 30 0
particle minecraft:happy_villager ~ ~1 ~ 0.4 0.4 0.4 0.1 15 force
playsound minecraft:entity.generic.drink master @a ~ ~ ~ 1 1