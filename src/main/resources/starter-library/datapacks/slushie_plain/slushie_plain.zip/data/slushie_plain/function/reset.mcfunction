data modify storage slushie_plain:global args set value {}
data modify storage slushie_plain stack set value []
gamerule max_command_sequence_length 1000000000