data modify storage slushie_plain:global args set value {}
data modify storage slushie_plain stack set value []
gamerule maxCommandChainLength 1000000000