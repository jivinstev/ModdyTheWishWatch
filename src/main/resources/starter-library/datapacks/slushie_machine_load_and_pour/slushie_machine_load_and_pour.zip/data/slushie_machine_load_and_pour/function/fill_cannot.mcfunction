playsound minecraft:entity.villager.no player @a[tag=mfam_filler,limit=1] ~ ~ ~ 1 1
scoreboard players set #empty mfam_fill 0
execute if score @s mfam_fl0 matches 0 if score @s mfam_fl1 matches 0 run scoreboard players set #empty mfam_fill 1
execute if score #empty mfam_fill matches 1 run tellraw @a[tag=mfam_filler,limit=1] ["",{"text":"It takes ","color":"yellow"},{"text":"Ice","color":"white"},{"text":"! Hold them and pull the handle.","color":"yellow"}]
execute if score #empty mfam_fill matches 0 run function slushie_machine_load_and_pour:fill_needs