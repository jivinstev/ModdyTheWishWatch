scoreboard players add @s mfam_fl0 0
scoreboard players add @s mfam_fl1 0
scoreboard players set #any mfam_fill 0
function slushie_machine_load_and_pour:fill_load0
function slushie_machine_load_and_pour:fill_load1
scoreboard players set #ready mfam_fill 0
execute if score @s mfam_fl0 matches 1.. run scoreboard players set #ready mfam_fill 1
execute if score #any mfam_fill matches 1 run function slushie_machine_load_and_pour:fill_loaded
# NOTHING NEW WENT IN, so this pull is a POUR — or, when it cannot pour, a sentence saying why.
execute if score #any mfam_fill matches 0 if score #ready mfam_fill matches 1 run function slushie_machine_load_and_pour:fill_pour
execute if score #any mfam_fill matches 0 if score #ready mfam_fill matches 0 run function slushie_machine_load_and_pour:fill_cannot