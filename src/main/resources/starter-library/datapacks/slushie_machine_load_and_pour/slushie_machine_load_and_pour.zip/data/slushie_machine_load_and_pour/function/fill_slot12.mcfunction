item replace block ~ ~ ~ container.12 from entity @s weapon.mainhand
item replace entity @s weapon.mainhand with minecraft:air