execute if score @s mfam_fl0 matches 1..1 unless score @s mfam_fl1 matches 1.. run function slushie_machine_load_and_pour:fill_out0
execute if score @s mfam_fl0 matches 1..1 if score @s mfam_fl1 matches 1.. run function slushie_machine_load_and_pour:fill_out1
execute if score @s mfam_fl0 matches 2..2 unless score @s mfam_fl1 matches 1.. run function slushie_machine_load_and_pour:fill_out2
execute if score @s mfam_fl0 matches 2..2 if score @s mfam_fl1 matches 1.. run function slushie_machine_load_and_pour:fill_out3
execute if score @s mfam_fl0 matches 3.. unless score @s mfam_fl1 matches 1.. run function slushie_machine_load_and_pour:fill_out4
execute if score @s mfam_fl0 matches 3.. if score @s mfam_fl1 matches 1.. run function slushie_machine_load_and_pour:fill_out5
scoreboard players set @s mfam_fl0 0
scoreboard players set @s mfam_fl1 0
playsound minecraft:block.brewing_stand.brew player @a[tag=mfam_filler,limit=1] ~ ~ ~ 1 1.2
particle minecraft:splash ~ ~1.5 ~ 0.3 0.4 0.3 0.1 24 force