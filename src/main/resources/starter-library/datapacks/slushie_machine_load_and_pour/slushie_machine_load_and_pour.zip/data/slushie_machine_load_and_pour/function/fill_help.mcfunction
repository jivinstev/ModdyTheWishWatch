tellraw @s ["",{"text":"Slushie Machine: hold Ice and pull the handle to load it.","color":"gold"}]
tellraw @s ["",{"text":"When it has them, pull again to pour a Slushie — more Ice makes a bigger one.","color":"white"}]
tellraw @s ["",{"text":"Add Sugar too, if you like!","color":"white"}]
tellraw @s ["",{"text":"It hands it to you.","color":"white"}]