scoreboard players set #took mfam_fill 0
execute if score @s mfam_fl1 matches ..0 store result score #took mfam_fill run clear @a[tag=mfam_filler,limit=1] minecraft:sugar 1
execute if score #took mfam_fill matches 1.. run scoreboard players add @s mfam_fl1 1
execute if score #took mfam_fill matches 1.. run scoreboard players set #any mfam_fill 1
execute if score #took mfam_fill matches 1.. run function slushie_machine_load_and_pour:fill_load1