execute if score #dir mfam_fill matches 1 positioned ~1 ~ ~ run function slushie_machine_load_and_pour:fill_slots
execute if score #dir mfam_fill matches 2 positioned ~-1 ~ ~ run function slushie_machine_load_and_pour:fill_slots
execute if score #dir mfam_fill matches 3 positioned ~ ~ ~1 run function slushie_machine_load_and_pour:fill_slots
execute if score #dir mfam_fill matches 4 positioned ~ ~ ~-1 run function slushie_machine_load_and_pour:fill_slots
execute if score #dir mfam_fill matches 5 positioned ~ ~-1 ~ run function slushie_machine_load_and_pour:fill_slots