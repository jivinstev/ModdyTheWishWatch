function slushie_machine_load_and_pour:give_one
give @s minecraft:ice 3
give @s minecraft:sugar 1
tellraw @s {"text":"You got Slushie Machine! Put it down, then pull the handle on the front! It makes Ice → Slushie. Here's 3 Ice and Sugar so you can try it!","color":"#4FC3F7"}