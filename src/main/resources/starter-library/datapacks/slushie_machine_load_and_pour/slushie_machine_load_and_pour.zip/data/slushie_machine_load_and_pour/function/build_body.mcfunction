setblock ~ ~ ~ minecraft:light_blue_concrete
execute if block ~ ~1 ~ #minecraft:replaceable run setblock ~ ~1 ~ minecraft:light_blue_stained_glass
execute if block ~ ~2 ~ #minecraft:replaceable run setblock ~ ~2 ~ minecraft:sea_lantern
playsound minecraft:block.copper.place block @a[distance=..32] ~ ~ ~ 1 1.2
particle minecraft:cloud ~ ~1.5 ~ 0.4 0.6 0.4 0.01 20 force
# Which way is the front? The anchor's yaw was snapped to a multiple of 45 and turned to face
# whoever placed it, so these five bands cover all nine possible values exactly once. They are
# deliberately NOT symmetrical: -45..45 and 45..135 would both claim 45.
execute if entity @s[y_rotation=-45..44.9] run function slushie_machine_load_and_pour:front_south
execute if entity @s[y_rotation=45..134.9] run function slushie_machine_load_and_pour:front_west
execute if entity @s[y_rotation=135..180] run function slushie_machine_load_and_pour:front_north
execute if entity @s[y_rotation=-180..-135.1] run function slushie_machine_load_and_pour:front_north
execute if entity @s[y_rotation=-135..-45.1] run function slushie_machine_load_and_pour:front_east