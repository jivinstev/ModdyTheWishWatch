scoreboard players set #dir mfam_fill 0
scoreboard players set #full mfam_fill 0
scoreboard players set #tochest mfam_fill 0
scoreboard players set #go mfam_fill 1
execute if entity @s[type=minecraft:armor_stand] run function slushie_machine_load_and_pour:fill_find_chest
execute if score #go mfam_fill matches 1 run function slushie_machine_load_and_pour:fill_serve