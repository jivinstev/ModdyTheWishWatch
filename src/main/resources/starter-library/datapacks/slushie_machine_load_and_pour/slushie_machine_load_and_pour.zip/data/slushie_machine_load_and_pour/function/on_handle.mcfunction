advancement revoke @s only slushie_machine_load_and_pour:pulled_the_handle
title @s actionbar {"text":"Slushie Machine","color":"#4FC3F7","bold":true}
# THE SIGN FOLLOWS THE RECIPE (#1043). A re-wish ("make it work with any log") changes the pack,
# not the sign already standing in the world -- so every pull rewrites the recipe lines from
# the pack he has now, and the sign never tells a lie about what the machine takes.
execute as @e[type=minecraft:armor_stand,tag=slushie_machine_load_and_pour_built,sort=nearest,limit=1,distance=..6] at @s run function slushie_machine_load_and_pour:refresh_sign
function slushie_machine_load_and_pour:effect