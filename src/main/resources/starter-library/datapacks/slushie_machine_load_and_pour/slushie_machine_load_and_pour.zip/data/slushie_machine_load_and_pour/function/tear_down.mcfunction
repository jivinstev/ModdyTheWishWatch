execute if entity @s[tag=slushie_machine_load_and_pour_s] if block ~ ~1 ~1 minecraft:lever run setblock ~ ~1 ~1 minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_s] if block ~ ~2 ~1 minecraft:birch_wall_sign run setblock ~ ~2 ~1 minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_n] if block ~ ~1 ~-1 minecraft:lever run setblock ~ ~1 ~-1 minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_n] if block ~ ~2 ~-1 minecraft:birch_wall_sign run setblock ~ ~2 ~-1 minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_e] if block ~1 ~1 ~ minecraft:lever run setblock ~1 ~1 ~ minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_e] if block ~1 ~2 ~ minecraft:birch_wall_sign run setblock ~1 ~2 ~ minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_w] if block ~-1 ~1 ~ minecraft:lever run setblock ~-1 ~1 ~ minecraft:air
execute if entity @s[tag=slushie_machine_load_and_pour_w] if block ~-1 ~2 ~ minecraft:birch_wall_sign run setblock ~-1 ~2 ~ minecraft:air
execute if block ~ ~ ~ minecraft:light_blue_concrete run setblock ~ ~ ~ minecraft:air
execute if block ~ ~1 ~ minecraft:light_blue_stained_glass run setblock ~ ~1 ~ minecraft:air
execute if block ~ ~2 ~ minecraft:sea_lantern run setblock ~ ~2 ~ minecraft:air
particle minecraft:cloud ~ ~1 ~ 0.4 0.6 0.4 0.02 25 force
# Hand the machine back rather than dropping parts, so a mistake costs nothing.
execute unless entity @s[tag=slushie_machine_load_and_pour_undo] if entity @p[distance=..24] run function slushie_machine_load_and_pour:refund
kill @s