execute unless block ~ ~ ~ minecraft:light_blue_concrete run tag @s add slushie_machine_load_and_pour_broken
execute unless block ~ ~1 ~ minecraft:light_blue_stained_glass run tag @s add slushie_machine_load_and_pour_broken
execute if entity @s[tag=slushie_machine_load_and_pour_broken] run function slushie_machine_load_and_pour:tear_down