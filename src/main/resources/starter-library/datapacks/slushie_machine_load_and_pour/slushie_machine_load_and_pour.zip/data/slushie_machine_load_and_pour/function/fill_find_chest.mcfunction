execute if score #dir mfam_fill matches 0 if block ~1 ~ ~ minecraft:chest run scoreboard players set #dir mfam_fill 1
execute if score #dir mfam_fill matches 0 if block ~1 ~ ~ minecraft:trapped_chest run scoreboard players set #dir mfam_fill 1
execute if score #dir mfam_fill matches 0 if block ~1 ~ ~ minecraft:barrel run scoreboard players set #dir mfam_fill 1
execute if score #dir mfam_fill matches 0 if block ~-1 ~ ~ minecraft:chest run scoreboard players set #dir mfam_fill 2
execute if score #dir mfam_fill matches 0 if block ~-1 ~ ~ minecraft:trapped_chest run scoreboard players set #dir mfam_fill 2
execute if score #dir mfam_fill matches 0 if block ~-1 ~ ~ minecraft:barrel run scoreboard players set #dir mfam_fill 2
execute if score #dir mfam_fill matches 0 if block ~ ~ ~1 minecraft:chest run scoreboard players set #dir mfam_fill 3
execute if score #dir mfam_fill matches 0 if block ~ ~ ~1 minecraft:trapped_chest run scoreboard players set #dir mfam_fill 3
execute if score #dir mfam_fill matches 0 if block ~ ~ ~1 minecraft:barrel run scoreboard players set #dir mfam_fill 3
execute if score #dir mfam_fill matches 0 if block ~ ~ ~-1 minecraft:chest run scoreboard players set #dir mfam_fill 4
execute if score #dir mfam_fill matches 0 if block ~ ~ ~-1 minecraft:trapped_chest run scoreboard players set #dir mfam_fill 4
execute if score #dir mfam_fill matches 0 if block ~ ~ ~-1 minecraft:barrel run scoreboard players set #dir mfam_fill 4
execute if score #dir mfam_fill matches 0 if block ~ ~-1 ~ minecraft:chest run scoreboard players set #dir mfam_fill 5
execute if score #dir mfam_fill matches 0 if block ~ ~-1 ~ minecraft:trapped_chest run scoreboard players set #dir mfam_fill 5
execute if score #dir mfam_fill matches 0 if block ~ ~-1 ~ minecraft:barrel run scoreboard players set #dir mfam_fill 5
execute if score #dir mfam_fill matches 1 if data block ~1 ~ ~ Items[26] run scoreboard players set #full mfam_fill 1
execute if score #dir mfam_fill matches 2 if data block ~-1 ~ ~ Items[26] run scoreboard players set #full mfam_fill 1
execute if score #dir mfam_fill matches 3 if data block ~ ~ ~1 Items[26] run scoreboard players set #full mfam_fill 1
execute if score #dir mfam_fill matches 4 if data block ~ ~ ~-1 Items[26] run scoreboard players set #full mfam_fill 1
execute if score #dir mfam_fill matches 5 if data block ~ ~-1 ~ Items[26] run scoreboard players set #full mfam_fill 1