function slushie_machine_load_and_pour:build_new
execute in minecraft:the_nether run function slushie_machine_load_and_pour:build_new
execute in minecraft:the_end run function slushie_machine_load_and_pour:build_new
execute as @e[tag=slushie_machine_load_and_pour_built] run scoreboard players add @s mfam_mach 1
execute as @e[tag=slushie_machine_load_and_pour_built,scores={mfam_mach=20..}] run scoreboard players set @s mfam_mach 0
execute as @e[tag=slushie_machine_load_and_pour_built,scores={mfam_mach=0}] at @s run function slushie_machine_load_and_pour:check_broken
execute in minecraft:the_nether as @e[tag=slushie_machine_load_and_pour_built,scores={mfam_mach=0}] at @s run function slushie_machine_load_and_pour:check_broken
execute in minecraft:the_end as @e[tag=slushie_machine_load_and_pour_built,scores={mfam_mach=0}] at @s run function slushie_machine_load_and_pour:check_broken