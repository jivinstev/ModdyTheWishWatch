data modify storage slushie_machine_load_and_pour:global args set value {}
data modify storage slushie_machine_load_and_pour stack set value []
gamerule max_command_sequence_length 1000000000
scoreboard objectives add mfam_mach dummy
# WHAT A CONVERSION TOOK. Declared by the SHAPE rather than by the effect, because an effect
# body has no reset hook of its own — and an objective that does not exist makes `execute store
# result` fail silently, which is the machine doing nothing with no error at all.
scoreboard objectives add mfam_conv dummy
scoreboard objectives add mfam_fill dummy
scoreboard objectives add mfam_fl0 dummy
scoreboard objectives add mfam_fl1 dummy