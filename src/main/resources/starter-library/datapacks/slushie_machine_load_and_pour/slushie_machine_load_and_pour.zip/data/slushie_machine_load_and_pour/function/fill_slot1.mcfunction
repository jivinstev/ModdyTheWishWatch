item replace block ~ ~ ~ container.1 from entity @s weapon.mainhand
item replace entity @s weapon.mainhand with minecraft:air