tag @s add mfam_filler
# SNEAK-PULL IS HELP, and does nothing else — so he can always find out how it works without
# spending an ingredient to learn.
execute if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_sneaking":true}}} run function slushie_machine_load_and_pour:fill_help
execute unless predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_sneaking":true}}} as @e[type=minecraft:armor_stand,tag=slushie_machine_load_and_pour_built,sort=nearest,limit=1,distance=..6] at @s run function slushie_machine_load_and_pour:fill_here
execute unless predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_sneaking":true}}} unless entity @e[type=minecraft:armor_stand,tag=slushie_machine_load_and_pour_built,distance=..6] run function slushie_machine_load_and_pour:fill_here
tag @s remove mfam_filler