data modify storage tiny_cookie_grow:global args set value {}
data modify storage tiny_cookie_grow stack set value []
gamerule max_command_sequence_length 1000000000
scoreboard objectives add mfam_grow dummy
execute as @e[scores={mfam_grow=0..},tag=!mfam_grow_on] run tag @s add mfam_grow_on