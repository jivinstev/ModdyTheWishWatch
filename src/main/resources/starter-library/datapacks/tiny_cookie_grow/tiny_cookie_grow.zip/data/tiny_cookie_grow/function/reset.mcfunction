data modify storage tiny_cookie_grow:global args set value {}
data modify storage tiny_cookie_grow stack set value []
gamerule maxCommandChainLength 1000000000
scoreboard objectives add mfam_grow dummy