execute as @s run attribute @s minecraft:scale base set 0.3
execute as @s run scoreboard players set @s mfam_grow 1200
execute as @s run tag @s add mfam_grow_on
particle minecraft:witch ~ ~1 ~ 0.5 0.8 0.5 0.1 40 force
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 0.7