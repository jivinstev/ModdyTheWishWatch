execute as @e[scores={mfam_grow=1..}] run scoreboard players remove @s mfam_grow 1
execute as @e[scores={mfam_grow=0}] run attribute @s minecraft:generic.scale base set 1
execute as @e[scores={mfam_grow=0}] at @s run playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1.4
execute as @e[scores={mfam_grow=0}] run scoreboard players reset @s mfam_grow