execute as @e[tag=mfam_grow_on,scores={mfam_grow=1..}] run scoreboard players remove @s mfam_grow 1
execute as @e[tag=mfam_grow_on,scores={mfam_grow=0}] run attribute @s minecraft:scale base set 1
execute as @e[tag=mfam_grow_on,scores={mfam_grow=0}] at @s run playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1.4
execute as @e[tag=mfam_grow_on,scores={mfam_grow=0}] run scoreboard players reset @s mfam_grow
execute as @e[tag=mfam_grow_on] unless score @s mfam_grow matches 0.. run tag @s remove mfam_grow_on
scoreboard players add #sweep mfam_grow 1
execute if score #sweep mfam_grow matches 200.. as @e[scores={mfam_grow=0..},tag=!mfam_grow_on] run tag @s add mfam_grow_on
execute if score #sweep mfam_grow matches 200.. run scoreboard players set #sweep mfam_grow 0