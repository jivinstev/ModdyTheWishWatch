data modify storage breath_cone_pet_dragon:global args set value {}
data modify storage breath_cone_pet_dragon stack set value []
gamerule maxCommandChainLength 1000000000
scoreboard objectives add mfam_breath dummy