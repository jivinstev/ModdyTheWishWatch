execute as @e[tag=wishmob_pet_dragon] run scoreboard players add @s mfam_breath 1
# the breath lasts BREATH_TICKS out of every PERIOD_TICKS -- a burst, not a permanent jet
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=1..40}] at @s anchored eyes run particle minecraft:flame ^ ^ ^1 0.1 0.1 0.1 0.02 25 force
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=1..40}] at @s anchored eyes run particle minecraft:flame ^ ^ ^2.5 0.4 0.4 0.4 0.02 25 force
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=1..40}] at @s anchored eyes run particle minecraft:flame ^ ^ ^4 0.8 0.8 0.8 0.02 25 force
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=1..40}] at @s anchored eyes run particle minecraft:flame ^ ^ ^5 1.1 1.1 1.1 0.02 25 force
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=1}] at @s run playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 1.4 1
# anything caught IN FRONT gets it. positioned ^ ^ ^N keeps the check on the breath line rather
# than in a ring around the creature -- otherwise this is just an aura with extra particles.
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=1..40}] at @s anchored eyes positioned ^ ^ ^3 run execute as @e[distance=..3.5,tag=!wishmob_pet_dragon,type=!minecraft:item] run execute if entity @s[type=!minecraft:player,tag=!wishmob_pet_dragon] run damage @s 4 minecraft:on_fire
execute as @e[tag=wishmob_pet_dragon,scores={mfam_breath=120..}] run scoreboard players set @s mfam_breath 0