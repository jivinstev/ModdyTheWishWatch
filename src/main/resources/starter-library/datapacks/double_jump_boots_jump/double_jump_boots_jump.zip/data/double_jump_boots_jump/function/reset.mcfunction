data modify storage double_jump_boots_jump:global args set value {}
data modify storage double_jump_boots_jump stack set value []
gamerule maxCommandChainLength 1000000000
scoreboard objectives add mfam_w_double_jump_boots_jump dummy