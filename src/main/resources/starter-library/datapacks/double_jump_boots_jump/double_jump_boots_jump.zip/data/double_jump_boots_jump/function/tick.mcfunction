execute as @a unless items entity @s armor.feet *[minecraft:custom_data~{WishItem:"double_jump_boots_jump"}] run scoreboard players reset @s mfam_w_double_jump_boots_jump
execute as @a if items entity @s armor.feet *[minecraft:custom_data~{WishItem:"double_jump_boots_jump"}] run scoreboard players add @s mfam_w_double_jump_boots_jump 1
execute as @a[scores={mfam_w_double_jump_boots_jump=1}] at @s run function double_jump_boots_jump:act
execute as @a[scores={mfam_w_double_jump_boots_jump=590..}] at @s run function double_jump_boots_jump:act
execute as @a[scores={mfam_w_double_jump_boots_jump=590..}] run scoreboard players set @s mfam_w_double_jump_boots_jump 1