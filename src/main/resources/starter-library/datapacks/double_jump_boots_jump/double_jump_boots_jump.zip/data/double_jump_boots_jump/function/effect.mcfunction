execute as @s run effect give @s minecraft:jump_boost 30 3 true
particle minecraft:cloud ~ ~0.1 ~ 0.3 0.05 0.3 0.02 12 force
playsound minecraft:entity.slime.jump master @a ~ ~ ~ 0.6 1.4