data modify storage teleport_wand_teleport:global args set value {}
data modify storage teleport_wand_teleport stack set value []
gamerule max_command_sequence_length 1000000000