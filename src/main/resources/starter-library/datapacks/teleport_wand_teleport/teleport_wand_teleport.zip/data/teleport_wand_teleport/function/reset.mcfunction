data modify storage teleport_wand_teleport:global args set value {}
data modify storage teleport_wand_teleport stack set value []
gamerule maxCommandChainLength 1000000000