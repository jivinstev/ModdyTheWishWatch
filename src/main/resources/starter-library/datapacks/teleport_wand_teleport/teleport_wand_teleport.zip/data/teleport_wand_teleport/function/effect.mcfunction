execute if block ~ ~ ~ #minecraft:replaceable as @s run tp @s ~ ~ ~
particle minecraft:portal ~ ~1 ~ 0.5 1.0 0.5 0.5 60 force
playsound minecraft:entity.enderman.teleport master @a ~ ~ ~ 1 1