scoreboard players add #t_wishmob_rainbow_axolotl mfam_hue 1
execute if score #t_wishmob_rainbow_axolotl mfam_hue matches 20.. if score #h_wishmob_rainbow_axolotl mfam_hue matches 0 as @e[tag=wishmob_rainbow_axolotl] run data modify entity @s Variant set value 0
execute if score #t_wishmob_rainbow_axolotl mfam_hue matches 20.. if score #h_wishmob_rainbow_axolotl mfam_hue matches 1 as @e[tag=wishmob_rainbow_axolotl] run data modify entity @s Variant set value 2
execute if score #t_wishmob_rainbow_axolotl mfam_hue matches 20.. if score #h_wishmob_rainbow_axolotl mfam_hue matches 2 as @e[tag=wishmob_rainbow_axolotl] run data modify entity @s Variant set value 3
execute if score #t_wishmob_rainbow_axolotl mfam_hue matches 20.. if score #h_wishmob_rainbow_axolotl mfam_hue matches 3 as @e[tag=wishmob_rainbow_axolotl] run data modify entity @s Variant set value 4
execute if score #t_wishmob_rainbow_axolotl mfam_hue matches 20.. run scoreboard players add #h_wishmob_rainbow_axolotl mfam_hue 1
execute if score #h_wishmob_rainbow_axolotl mfam_hue matches 4.. run scoreboard players set #h_wishmob_rainbow_axolotl mfam_hue 0
execute if score #t_wishmob_rainbow_axolotl mfam_hue matches 20.. run scoreboard players set #t_wishmob_rainbow_axolotl mfam_hue 0