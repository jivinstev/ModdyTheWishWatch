data modify storage colour_cycle_rainbow_axolotl:global args set value {}
data modify storage colour_cycle_rainbow_axolotl stack set value []
gamerule maxCommandChainLength 1000000000
scoreboard objectives add mfam_hue dummy
scoreboard players set #t_wishmob_rainbow_axolotl mfam_hue 0
scoreboard players set #h_wishmob_rainbow_axolotl mfam_hue 0