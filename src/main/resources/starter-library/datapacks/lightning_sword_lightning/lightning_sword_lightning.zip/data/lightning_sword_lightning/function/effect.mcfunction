tag @s[type=minecraft:player] add moddy_bolt_maker
summon minecraft:lightning_bolt ~ ~ ~