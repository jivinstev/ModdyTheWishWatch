data modify storage lightning_sword_lightning:global args set value {}
data modify storage lightning_sword_lightning stack set value []
gamerule maxCommandChainLength 1000000000