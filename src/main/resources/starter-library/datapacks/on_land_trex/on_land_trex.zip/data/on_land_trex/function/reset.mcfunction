data modify storage on_land_trex:global args set value {}
data modify storage on_land_trex stack set value []
gamerule maxCommandChainLength 1000000000
scoreboard objectives add mfam_landair dummy