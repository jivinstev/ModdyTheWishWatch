scoreboard players set @s mfam_blk 0
function lucky_block_outcome_table:effect