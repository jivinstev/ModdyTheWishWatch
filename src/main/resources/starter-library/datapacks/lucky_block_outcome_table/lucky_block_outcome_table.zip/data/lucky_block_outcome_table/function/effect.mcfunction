execute store result score @s mfam_luck run random value 1..100
execute if score @s mfam_luck matches 1..16 run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:diamond",count:3},Motion:[0.0,0.3,0.0]}
execute if score @s mfam_luck matches 17..32 run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:cake",count:1},Motion:[0.0,0.3,0.0]}
execute if score @s mfam_luck matches 33..48 run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:golden_apple",count:1},Motion:[0.0,0.3,0.0]}
execute if score @s mfam_luck matches 49..64 run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:emerald",count:5},Motion:[0.0,0.3,0.0]}
execute if score @s mfam_luck matches 65..80 run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:enchanted_golden_apple",count:1},Motion:[0.0,0.3,0.0]}
execute if score @s mfam_luck matches 81..86 run summon minecraft:chicken ~ ~ ~
execute if score @s mfam_luck matches 87..91 run summon minecraft:pig ~ ~ ~
execute if score @s mfam_luck matches 92..96 run summon minecraft:zombie ~ ~ ~
execute if score @s mfam_luck matches 97..100 run summon minecraft:tnt ~ ~ ~ {fuse:40}
particle minecraft:happy_villager ~ ~0.5 ~ 0.4 0.4 0.4 0.1 20 force
playsound minecraft:entity.player.levelup master @a[distance=..16] ~ ~ ~ 0.8 1.4