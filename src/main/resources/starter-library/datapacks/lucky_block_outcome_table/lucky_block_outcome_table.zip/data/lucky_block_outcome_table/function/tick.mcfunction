function lucky_block_outcome_table:build_new
execute as @e[type=minecraft:armor_stand,tag=lucky_block_outcome_table_built] at @s run function lucky_block_outcome_table:check_broken
scoreboard players add @e[type=minecraft:armor_stand,tag=lucky_block_outcome_table_built,scores={mfam_blk=..100000}] mfam_blk 1