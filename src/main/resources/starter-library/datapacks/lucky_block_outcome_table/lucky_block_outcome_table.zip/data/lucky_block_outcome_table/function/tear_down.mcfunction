execute unless entity @s[tag=lucky_block_outcome_table_undo] run function lucky_block_outcome_table:on_broken
execute if block ~ ~ ~ minecraft:gold_block run setblock ~ ~ ~ minecraft:air
kill @e[type=minecraft:item,distance=..1.5,nbt={Item:{id:"minecraft:gold_block"}}]
kill @s