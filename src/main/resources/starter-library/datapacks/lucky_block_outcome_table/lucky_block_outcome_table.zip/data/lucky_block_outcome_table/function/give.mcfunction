function lucky_block_outcome_table:give_one
tellraw @s {"text":"You got Lucky Block! Right-click the ground to put it down, and see what it does!","color":"#FFD54F"}