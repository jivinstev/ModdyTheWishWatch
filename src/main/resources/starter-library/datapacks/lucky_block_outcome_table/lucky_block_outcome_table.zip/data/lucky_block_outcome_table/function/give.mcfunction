function lucky_block_outcome_table:give_one
tellraw @s {"text":"You got Lucky Block! Use it on the ground to put it down, and see what it does!","color":"#FFD54F"}