execute if block ~ ~ ~ #minecraft:replaceable run setblock ~ ~ ~ minecraft:gold_block
playsound minecraft:block.amethyst_block.place block @a[distance=..32] ~ ~ ~ 1 1
particle minecraft:end_rod ~ ~0.6 ~ 0.3 0.3 0.3 0.02 12 force