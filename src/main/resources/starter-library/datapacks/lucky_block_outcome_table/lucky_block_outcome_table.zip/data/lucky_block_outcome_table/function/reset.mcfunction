data modify storage lucky_block_outcome_table:global args set value {}
data modify storage lucky_block_outcome_table stack set value []
gamerule max_command_sequence_length 1000000000
# The beat and the rest between goes, counted ON EACH BLOCK so two of them never share one dial.
scoreboard objectives add mfam_blk dummy
scoreboard objectives add mfam_luck dummy