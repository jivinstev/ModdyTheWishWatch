tag @s remove lucky_block_outcome_table_new
tag @s add lucky_block_outcome_table_built
scoreboard players set @s mfam_blk 0
function lucky_block_outcome_table:build_body